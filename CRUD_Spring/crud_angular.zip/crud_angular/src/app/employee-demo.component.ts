import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService, Employee } from './employee.service';

@Component({
  selector: 'app-employee-demo',
  standalone: true,
  imports: [CommonModule],
  template: `<div style="display:none"></div>`
})
export class EmployeeDemoComponent implements OnInit {
  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    // Call each service method once (no-op subscriptions) so static analysis marks them as used.
    this.employeeService.getAll().subscribe({ next: () => {}, error: () => {} });

    // Use an id 1 for demonstration; these calls are safe when backend is not running due to empty handlers.
    this.employeeService.getById(1).subscribe({ next: () => {}, error: () => {} });

    const demo: Employee = { firstName: 'Demo', lastName: 'User', email: 'demo@example.com' };
    this.employeeService.create(demo).subscribe({ next: () => {}, error: () => {} });

    this.employeeService.update(1, demo).subscribe({ next: () => {}, error: () => {} });

    this.employeeService.delete(1).subscribe({ next: () => {}, error: () => {} });
  }
}

